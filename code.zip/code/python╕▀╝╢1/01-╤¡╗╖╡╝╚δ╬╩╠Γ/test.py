def test():
    print("------1----")
    print("------2----")
