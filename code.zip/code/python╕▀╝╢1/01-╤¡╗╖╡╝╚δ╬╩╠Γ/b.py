from a import a

def b():
    print("----b---")

def c():
    print("----c---")
    a()

c()
