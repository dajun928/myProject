import os

ret = os.fork()
print("haha")
