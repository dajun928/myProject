def test():
    print("haha")
    test()


test()
