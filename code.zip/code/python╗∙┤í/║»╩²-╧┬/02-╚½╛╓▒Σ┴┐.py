
a = 100

def test1():
    print("a=%d"%a)

def test2():
    print("a=%d"%a)

test1()
test2()
