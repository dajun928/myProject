def test1():
    a = 100

def test2():
    print("a=%d"%a)


test1()
#test2()

print("a=%d"%a)
