def print_line():
    print("-"*50)

def print_5_line():
    i = 0
    while i<5:
        print_line()
        i+=1
   

print_5_line()
