nums = [11,22,33,44,55]

#while循环的遍历方式
#nums_lenght = len(nums)
#i = 0 
#while i<nums_lenght:
#    print(nums[i])
#    i+=1

#for循环的遍历方式(因为不用控制元素的个数，以及下标，所以使用起来会更简单)
for num in nums:
    print(num)
