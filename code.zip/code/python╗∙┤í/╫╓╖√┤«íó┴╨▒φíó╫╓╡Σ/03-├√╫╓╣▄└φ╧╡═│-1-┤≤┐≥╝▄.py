#1. 打印功能提示
print("="*50)
print("    名字关系系统 V8.6")
print(" 1:添加一个新的名字")
print(" 2:删除一个名字")
print(" 3:修改一个名字")
print(" 4:查询一个名字")
print("="*50)

#2. 获取用的选择
num = int(input("请输入功能序号:"))

#3. 根据用户的选择,执行相应的功能
if num==1:
    pass
elif num==2:
    pass
elif num==3:
    pass
elif num==4:
    pass
else:
    print("您的输入有误,请重新输入")
