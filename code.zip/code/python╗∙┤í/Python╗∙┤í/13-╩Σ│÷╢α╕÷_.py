#coding=utf-8

#1. 使用input获取必要的信息
name = input("请输入名字:")
QQ = input("请输入QQ:")

#2. 使用print来打印名片
print("="*50)
print("姓名:%s"%name)
print("QQ:%s"%QQ)
print("="*50)


