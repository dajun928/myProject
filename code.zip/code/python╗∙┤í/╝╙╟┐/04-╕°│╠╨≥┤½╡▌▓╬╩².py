import sys

print(sys.argv)

name = sys.argv[1]

print("热烈欢迎 %s的到来"%name)
