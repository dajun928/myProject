import time

while True:
    print("haha")
    time.sleep(1)
