a = 4
b = 5

#第1种
#c = 0
#c = a
#a = b
#b = c

#第2种
#a = a+b
#b = a-b
#a = a-b

#第3种
a,b = b,a

print("a=%d,b=%d"%(a,b))
