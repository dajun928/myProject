a = 30

if not (a>0 and a<=50):
    print("在0到50之间....")
