i=1
#用来控制行数
while i<=5:

    #用来控制每一行中的列数
    j = 1
    while j<=5:
        print("*", end="")
        #j = j+1#c语言中向让j加上1的方式: j++;    ++j;   j+=1;  j=j+1;
        j+=1

    print("")

    i = i+1
