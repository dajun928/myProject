i = 1
while i<=5:

    print("-----")

    if i==3:
       break

    print(i)

    i+=1
