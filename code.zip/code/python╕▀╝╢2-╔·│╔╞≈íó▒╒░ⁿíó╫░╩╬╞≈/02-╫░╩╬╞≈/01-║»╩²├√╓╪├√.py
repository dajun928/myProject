def test1():
    print("---1---")

def test1():
    print("---2---")

test1()
